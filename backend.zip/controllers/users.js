const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/user");
const { SUCCESS, CREATED } = require("../utils/errors");
const { JWT_SECRET } = require("../utils/config");

const BadRequestError = require("../errors/badRequestError");
const NotFoundError = require("../errors/notFoundError");
const UnauthorizedError = require("../errors/unauthorizedError");
const Conflict = require("../errors/conflictError");

const signup = (req, res, next) => {
  const { name, email, password } = req.body;
  if (!email || !password) {
    return next(new BadRequestError("Email and Password are required."));
  }

  return User.findOne({ email })
    .then((user) => {
      if (user) {
        throw new Conflict("User already exist.");
      }

      return bcrypt.hash(password, 10);
    })
    .then((hash) => User.create({ name, email, password: hash }))
    .then((user) =>
      res.status(CREATED).send({
        name: user.name,
        email: user.email,
      })
    )

    .catch((err) => {
      if (err.name === "ValidationError") {
        return next(new BadRequestError("Bad request: Invalid data sent"));
      }

      return next(err);
    });
};

const getCurrentUser = (req, res, next) => {
  const currentUser = req.user;
  User.findById(currentUser._id)
    .then((user) => res.status(SUCCESS).send(user))
    .catch((err) => {
      if (err.name === "DocumentNotFoundError") {
        return next(new NotFoundError("User Not Found."));
      }
      if (err.name === "CastError") {
        return next(new BadRequestError("Invalid user id."));
      }
      return next(err);
    });
};

const signin = (req, res, next) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return next(new BadRequestError("Email or password required"));
  }
  return User.findUserByCredentials(email, password)
    .then((user) => {
      const token = jwt.sign({ _id: user._id }, JWT_SECRET, {
        expiresIn: "7d",
      });
      return res.send({ token });
    })
    .catch((err) => {
      if (err.message === "Incorrect email or password") {
        return next(new UnauthorizedError("Incorrect email or password"));
      }
      return next(err);
    });
};

module.exports = { getCurrentUser, signin, signup };
